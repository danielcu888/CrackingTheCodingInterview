/*
 * BubbleSort.h
 *
 *  Created on: Mar 6, 2012
 *      Author: danielcumberbatch
 */

#ifndef BUBBLESORT_H_
#define BUBBLESORT_H_

#include "Person.h"
#include <cstddef>

void bubblesort(Person *array[], std::size_t);

#endif /* BUBBLESORT_H_ */
