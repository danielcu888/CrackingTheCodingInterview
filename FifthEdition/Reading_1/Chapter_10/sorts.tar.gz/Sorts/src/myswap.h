/*
 * myswap.h
 *
 *  Created on: Mar 6, 2012
 *      Author: danielcumberbatch
 */

#ifndef MYSWAP_H_
#define MYSWAP_H_

#include "Person.h"

void myswap(Person **p1, Person **p2);

#endif /* MYSWAP_H_ */
