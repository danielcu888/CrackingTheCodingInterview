/*
 * ShellSort.h
 *
 *  Created on: Mar 6, 2012
 *      Author: danielcumberbatch
 */

#ifndef SHELLSORT_H_
#define SHELLSORT_H_

#include "Person.h"

void shellsort(Person *array[], int);

#endif /* SHELLSORT_H_ */
